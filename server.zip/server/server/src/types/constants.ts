export const DEFAULT_NAME_DB_CONNECION: string = "roadmap";
export const SESSION_LENGTH: number = 30;
export const TEN_PERCENT_OF_DAY: number = 8640000;
export const TEN_MINUTES_IN_MILLISECONDS: number = 6000;
export const EMPTY_POSITION_ID: number = 500000;

export enum USER_POSITIONS {
	COMADER = 0,
}
